package com.example.graveplugin;

import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class GraveListener implements Listener {

    private final GravePlugin plugin;
    private final GraveManager graveManager;

    public GraveListener(GravePlugin plugin, GraveManager graveManager) {
        this.plugin = plugin;
        this.graveManager = graveManager;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        if (event.getKeepInventory()) {
            return; // Inventar bleibt ohnehin erhalten -> kein Grab noetig
        }

        List<ItemStack> items = new ArrayList<>();
        for (ItemStack stack : event.getDrops()) {
            if (stack != null && stack.getType() != Material.AIR) {
                items.add(stack.clone());
            }
        }

        if (items.isEmpty()) {
            return; // nichts zu lagern
        }

        event.getDrops().clear();
        graveManager.createGrave(player, items);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return; // verhindert doppeltes Oeffnen (Haupt- + Nebenhand)
        }

        Entity clicked = event.getRightClicked();
        if (!graveManager.isGrave(clicked)) {
            return;
        }

        event.setCancelled(true);

        ArmorStand stand = (ArmorStand) clicked;
        GraveInventoryHolder holder = graveManager.getHolder(stand.getUniqueId());
        if (holder == null || holder.getInventory() == null) {
            return;
        }

        event.getPlayer().openInventory(holder.getInventory());
    }

    @EventHandler
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        if (graveManager.isGrave(event.getRightClicked())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (graveManager.isGrave(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof GraveInventoryHolder holder)) {
            return;
        }

        InventoryAction action = event.getAction();
        Inventory clickedInv = event.getClickedInventory();

        if (clickedInv != null && clickedInv.equals(top)) {
            // Klick im Grab-Inventar: nur Entnehmen erlauben, niemals Hineinlegen
            switch (action) {
                case PLACE_ALL, PLACE_SOME, PLACE_ONE, SWAP_WITH_CURSOR,
                     HOTBAR_SWAP, HOTBAR_MOVE_AND_READD, UNKNOWN -> event.setCancelled(true);
                default -> { /* Entnehmen (PICKUP_*, MOVE_TO_OTHER_INVENTORY, DROP, ...) erlaubt */ }
            }
        } else if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            // Shift-Klick im eigenen Inventar wuerde Items ins Grab legen -> verhindern
            event.setCancelled(true);
        }

        // einen Tick spaeter pruefen, ob das Grab jetzt leer ist (Klick ist dann verarbeitet)
        plugin.getServer().getScheduler().runTask(plugin,
                () -> graveManager.checkAndScheduleRemoval(holder.getGraveEntityId()));
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof GraveInventoryHolder)) {
            return;
        }

        int topSize = top.getSize();
        for (int slot : event.getRawSlots()) {
            if (slot < topSize) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
