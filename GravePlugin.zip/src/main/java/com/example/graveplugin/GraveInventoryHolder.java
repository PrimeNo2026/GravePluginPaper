package com.example.graveplugin;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Markiert ein Inventory eindeutig als Grab-Inventar und verknuepft es
 * mit der ArmorStand-Entity, die das Grab in der Welt darstellt.
 */
public class GraveInventoryHolder implements InventoryHolder {

    private final UUID graveEntityId;
    private Inventory inventory;
    private boolean removalScheduled = false;

    public GraveInventoryHolder(UUID graveEntityId) {
        this.graveEntityId = graveEntityId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }

    public UUID getGraveEntityId() {
        return graveEntityId;
    }

    public boolean isRemovalScheduled() {
        return removalScheduled;
    }

    public void setRemovalScheduled(boolean removalScheduled) {
        this.removalScheduled = removalScheduled;
    }
}
