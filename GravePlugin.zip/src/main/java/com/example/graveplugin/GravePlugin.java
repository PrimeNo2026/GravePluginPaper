package com.example.graveplugin;

import org.bukkit.plugin.java.JavaPlugin;

public class GravePlugin extends JavaPlugin {

    private GraveManager graveManager;

    @Override
    public void onEnable() {
        this.graveManager = new GraveManager(this);
        getServer().getPluginManager().registerEvents(new GraveListener(this, graveManager), this);
        getLogger().info("GravePlugin wurde aktiviert.");
    }

    @Override
    public void onDisable() {
        getLogger().info("GravePlugin wurde deaktiviert.");
    }

    public GraveManager getGraveManager() {
        return graveManager;
    }
}
