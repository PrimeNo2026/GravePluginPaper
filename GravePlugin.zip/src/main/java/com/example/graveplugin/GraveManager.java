package com.example.graveplugin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Erstellt Graeber, haelt sie im Speicher und entfernt sie wieder,
 * sobald sie leergeraeumt wurden.
 */
public class GraveManager {

    private static final long REMOVE_DELAY_TICKS = 20L * 10L; // 10 Sekunden

    private final GravePlugin plugin;
    private final NamespacedKey graveKey;
    private final Map<UUID, GraveInventoryHolder> graves = new HashMap<>();

    public GraveManager(GravePlugin plugin) {
        this.plugin = plugin;
        this.graveKey = new NamespacedKey(plugin, "grave");
    }

    public boolean isGrave(Entity entity) {
        if (!(entity instanceof ArmorStand stand)) {
            return false;
        }
        return stand.getPersistentDataContainer().has(graveKey, PersistentDataType.BYTE);
    }

    public GraveInventoryHolder getHolder(UUID graveEntityId) {
        return graves.get(graveEntityId);
    }

    /**
     * Spawnt ein neues Grab am Ort des Spielers und befuellt es mit den
     * uebergebenen Items.
     */
    public GraveInventoryHolder createGrave(Player player, List<ItemStack> items) {
        Location loc = player.getLocation();
        ArmorStand stand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);

        // keine Physik / Schwerkraft, keine Kollision, unzerstoerbar, keine KI
        stand.setGravity(false);
        stand.setInvulnerable(true);
        stand.setCollidable(false);
        stand.setCanPickupItems(false);
        stand.setBasePlate(true);
        stand.setArms(true);
        stand.setVisible(true);
        stand.setCustomName("Grab von " + player.getName());
        stand.setCustomNameVisible(true);

        // Markierung, damit wir die Entity spaeter eindeutig als Grab erkennen
        stand.getPersistentDataContainer().set(graveKey, PersistentDataType.BYTE, (byte) 1);

        // Spielerkopf als optische Kennzeichnung des Koerpers
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(player);
            skull.setItemMeta(meta);
        }
        if (stand.getEquipment() != null) {
            stand.getEquipment().setHelmet(skull);
        }

        int size = inventorySizeFor(items.size());
        GraveInventoryHolder holder = new GraveInventoryHolder(stand.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, size, "Grab von " + player.getName());
        holder.setInventory(inventory);

        for (ItemStack item : items) {
            if (item != null && item.getType() != Material.AIR) {
                inventory.addItem(item);
            }
        }

        graves.put(stand.getUniqueId(), holder);
        return holder;
    }

    private int inventorySizeFor(int itemCount) {
        int rows = (int) Math.ceil(itemCount / 9.0);
        rows = Math.max(1, Math.min(rows, 6));
        return rows * 9;
    }

    /**
     * Prueft, ob ein Grab leer ist und plant danach dessen Entfernung
     * nach 10 Sekunden ein (nur einmal pro Grab).
     */
    public void checkAndScheduleRemoval(UUID graveEntityId) {
        GraveInventoryHolder holder = graves.get(graveEntityId);
        if (holder == null || holder.isRemovalScheduled() || holder.getInventory() == null) {
            return;
        }

        for (ItemStack item : holder.getInventory().getContents()) {
            if (item != null && item.getType() != Material.AIR) {
                return; // noch nicht leer
            }
        }

        holder.setRemovalScheduled(true);
        Bukkit.getScheduler().runTaskLater(plugin, () -> removeGrave(graveEntityId), REMOVE_DELAY_TICKS);
    }

    public void removeGrave(UUID graveEntityId) {
        GraveInventoryHolder holder = graves.remove(graveEntityId);
        if (holder == null) {
            return;
        }

        if (holder.getInventory() != null) {
            for (HumanEntity viewer : new ArrayList<>(holder.getInventory().getViewers())) {
                viewer.closeInventory();
            }
        }

        Entity entity = Bukkit.getEntity(graveEntityId);
        if (entity != null) {
            entity.remove();
        }
    }
}
