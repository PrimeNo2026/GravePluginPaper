# GravePlugin

Ein einfaches Paper-Plugin (Paper/Minecraft 26.3), das beim Tod eines Spielers ein
Grab an der Todesstelle hinterlaesst, statt die Items auf dem Boden zu droppen.

## Funktionen

- Beim Tod werden alle Items, die der Spieler im Inventar hatte, **nicht** gedroppt,
  sondern in einem Grab gespeichert.
- Das Grab ist eine unsichtbare/kaum interagierbare ArmorStand-Entity mit Spielerkopf
  und Namensschild "Grab von &lt;Spieler&gt;".
- Keine Schwerkraft, keine Kollision, kein Lebensbalken/Herzen, unzerstoerbar
  (kann nicht angegriffen oder abgebaut werden).
- **Jeder** Spieler kann per Rechtsklick auf das Grab die Items entnehmen.
- Es koennen **keine** Items in das Grab hineingelegt werden (weder per Klick noch
  per Shift-Klick oder Drag).
- 10 Sekunden nachdem das Grab komplett leergeraeumt wurde, verschwindet es automatisch.

## Build (automatisch via GitHub Actions)

1. Erstelle ein neues GitHub-Repository und lade den **gesamten Inhalt** dieses
   Ordners (nicht die ZIP-Datei selbst, sondern die darin enthaltenen Dateien/Ordner)
   per Drag & Drop oder `git push` hoch. Die Ordnerstruktur (inkl. `.github/workflows/`)
   muss erhalten bleiben.
2. GitHub Actions baut das Plugin automatisch bei jedem Push auf den `main`-Branch
   (Tab **Actions** im Repository).
3. Nach erfolgreichem Lauf findest du unter dem jeweiligen Workflow-Run im Bereich
   **Artifacts** die Datei `GravePlugin-jar`, die die fertige `graveplugin.jar` enthaelt.
4. `graveplugin.jar` in den `plugins`-Ordner deines Paper-26.3-Servers legen und
   Server (neu) starten.

## Lokaler Build (optional)

Falls du lieber lokal baust (JDK 21+ noetig):

```bash
mvn package
```

Die fertige Datei liegt danach unter `target/graveplugin.jar`.

## Hinweise / Grenzen

- Die Paper-API-Version ist als Bereich `[26.3.build,)` eingetragen, damit Maven
  automatisch den neuesten verfuegbaren 26.3(.x)-Build nutzt. Falls dein Server
  bereits eine neuere Hauptversion hat (z. B. 26.4), passe die Zahl in `pom.xml`
  bei Bedarf an.
- Graeber werden nur im Arbeitsspeicher verwaltet. Bei einem Serverneustart gehen
  noch offene Graeber verloren (sie sind dann als "normale" ArmorStand-Entity in der
  Welt vorhanden, aber ohne Funktion). Sag Bescheid, falls du Persistenz ueber
  Neustarts hinweg (z. B. via JSON/SQLite) brauchst, das kann ich ergaenzen.
- Der "Koerper" ist aus API-Gruenden eine ArmorStand-Figur mit Spielerkopf, kein
  echtes Spielermodell (das waere nur ueber zusaetzliche NPC-Bibliotheken wie
  Citizens moeglich).
